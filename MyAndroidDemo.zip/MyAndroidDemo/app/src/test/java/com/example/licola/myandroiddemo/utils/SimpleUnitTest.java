package com.example.licola.myandroiddemo.utils;

import org.junit.Test;

/**
 * Created by LiCola on 2017/6/21.
 */

public class SimpleUnitTest {

  @Test
  public void stringOperate(){
    String name="DBManagerImpl";
    System.out.println(name.replace("Impl",""));
  }
}
