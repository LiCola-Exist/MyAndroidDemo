package com.example.licola.myandroiddemo.dagger;

/**
 * Created by 李可乐 on 2017/1/24 0024.
 */

public class SuperUserModel {

    private String superName;

    public SuperUserModel(String superName) {
        this.superName = superName;
    }

    public String getSuperName() {
        return superName;
    }
}
