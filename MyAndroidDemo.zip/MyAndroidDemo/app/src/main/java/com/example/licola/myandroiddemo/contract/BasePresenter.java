package com.example.licola.myandroiddemo.contract;

/**
 * Created by 李可乐 on 2017/1/19 0019.
 */

public interface BasePresenter {
    void start();

    void openDialog(String date);
}
