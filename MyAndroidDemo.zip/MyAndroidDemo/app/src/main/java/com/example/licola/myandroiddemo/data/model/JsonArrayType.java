package com.example.licola.myandroiddemo.data.model;

/**
 * Created by LiCola on 2018/5/19.
 */
public class JsonArrayType {

  /**
   * type : JsonArrayItem
   */

  private String type;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }
}
