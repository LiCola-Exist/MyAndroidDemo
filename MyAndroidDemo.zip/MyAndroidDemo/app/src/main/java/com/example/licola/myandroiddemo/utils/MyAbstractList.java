package com.example.licola.myandroiddemo.utils;

import java.util.ArrayList;

/**
 * Created by 李可乐 on 2017/4/14.
 */

public abstract class MyAbstractList implements MyList {

  public abstract void size();

}
