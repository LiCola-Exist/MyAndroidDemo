package com.example.licola.myandroiddemo.utils;

/**
 * Created by 李可乐 on 2017/4/14.
 */

public interface MyList {

  void size();
}
