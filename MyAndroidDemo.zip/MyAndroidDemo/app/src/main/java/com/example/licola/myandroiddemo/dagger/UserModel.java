package com.example.licola.myandroiddemo.dagger;

/**
 * Created by 李可乐 on 2017/1/24 0024.
 */

public class UserModel {
    private String name;

    public UserModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
