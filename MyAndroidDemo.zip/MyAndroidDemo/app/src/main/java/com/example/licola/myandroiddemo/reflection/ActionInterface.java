package com.example.licola.myandroiddemo.reflection;

/**
 * Created by 李可乐 on 2017/4/18.
 */

public interface ActionInterface {
  void action(boolean isAction);
}
