package com.example.licola.myandroiddemo.data.model;

/**
 * Created by LiCola on 2017/6/9.
 */

public enum Type {
  Action,
  Operate,
  None
}
