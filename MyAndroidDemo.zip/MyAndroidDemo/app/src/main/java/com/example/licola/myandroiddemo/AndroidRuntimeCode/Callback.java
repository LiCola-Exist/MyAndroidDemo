package com.example.licola.myandroiddemo.AndroidRuntimeCode;

/**
 * Created by 李可乐 on 2017/4/21.
 */

public abstract class Callback {

}
