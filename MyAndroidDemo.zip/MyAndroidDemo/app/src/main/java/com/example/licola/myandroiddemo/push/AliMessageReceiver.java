package com.example.licola.myandroiddemo.push;

import com.alibaba.sdk.android.push.MessageReceiver;

/**
 * Created by LiCola on 2017/6/16.
 */

public class AliMessageReceiver extends MessageReceiver {
}
