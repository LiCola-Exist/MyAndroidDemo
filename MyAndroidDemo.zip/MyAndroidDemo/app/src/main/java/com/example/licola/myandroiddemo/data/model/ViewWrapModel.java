package com.example.licola.myandroiddemo.data.model;

import android.arch.lifecycle.ViewModel;

/**
 * Created by LiCola on 2017/6/9.
 */

public class ViewWrapModel  extends ViewModel {
}
