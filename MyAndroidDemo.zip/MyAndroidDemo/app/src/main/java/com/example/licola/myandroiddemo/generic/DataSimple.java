package com.example.licola.myandroiddemo.generic;

/**
 * Created by 李可乐 on 2017/4/21.
 */

public class DataSimple {
    public static class Fruit{

    }

    public static class Apple extends Fruit{

    }

    public static class Orange extends Fruit{

    }


}
