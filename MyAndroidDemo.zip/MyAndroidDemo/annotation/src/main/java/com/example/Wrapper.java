package com.example;


public class Wrapper {
  public interface Component {

    void method(String date);
  }

}
